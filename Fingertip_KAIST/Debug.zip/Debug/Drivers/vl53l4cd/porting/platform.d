Drivers/vl53l4cd/porting/platform.o: \
 ../Drivers/vl53l4cd/porting/platform.c \
 ../Drivers/vl53l4cd/modules/vl53l4cd_api.h \
 ../Drivers/vl53l4cd/porting/platform.h \
 C:/Users/liuai/BRL/KAISTfingertip_firmware/Fingertip_KAIST/Drivers/vl53l4cd/vl53l4cd.h
../Drivers/vl53l4cd/modules/vl53l4cd_api.h:
../Drivers/vl53l4cd/porting/platform.h:
C:/Users/liuai/BRL/KAISTfingertip_firmware/Fingertip_KAIST/Drivers/vl53l4cd/vl53l4cd.h:
